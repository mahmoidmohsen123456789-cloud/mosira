// Slide-over cart panel with line items + checkout trigger
import { useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { useLang } from "@/contexts/LanguageContext";
import CheckoutDialog from "@/components/CheckoutDialog";

export default function CartPanel() {
  const { lines, setQty, remove, subtotal, count, open, setOpen, clear } = useCart();
  const { lang, tr } = useLang();
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  return (
    <>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="w-full sm:max-w-md bg-background border-l border-primary/20 p-0 flex flex-col">
          <SheetHeader className="px-6 pt-6 pb-4 border-b border-primary/15">
            <SheetTitle className="font-display text-2xl text-gradient-gold flex items-center gap-2">
              <ShoppingBag className="h-5 w-5 text-gold" />
              {tr("cartTitle")} {count > 0 && <span className="text-base text-muted-foreground">({count})</span>}
            </SheetTitle>
          </SheetHeader>

          <div className="flex-1 overflow-y-auto px-6 py-4">
            {lines.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-muted-foreground gap-3">
                <ShoppingBag className="h-12 w-12 text-primary/30" />
                <p>{tr("cartEmpty")}</p>
              </div>
            ) : (
              <ul className="space-y-3">
                {lines.map(({ dish, qty }) => (
                  <li
                    key={dish.id}
                    className="flex gap-3 rounded-xl border border-primary/15 bg-card p-3 hover:border-primary/35 transition-colors"
                  >
                    <img src={dish.image} alt={dish.nameEn} className="h-20 w-20 rounded-lg object-cover shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="font-display text-base text-foreground leading-tight truncate">
                        {lang === "ar" ? dish.nameAr : dish.nameEn}
                      </p>
                      <p className="text-xs text-gold mt-0.5">
                        {dish.price} {lang === "ar" ? "ج.م" : "EGP"}
                      </p>
                      <div className="mt-2 flex items-center gap-2">
                        <button
                          onClick={() => setQty(dish.id, qty - 1)}
                          className="cursor-hover h-7 w-7 grid place-items-center rounded-full border border-primary/30 text-gold hover:bg-primary/10"
                          aria-label="Decrease"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="min-w-6 text-center text-sm font-semibold text-foreground">{qty}</span>
                        <button
                          onClick={() => setQty(dish.id, qty + 1)}
                          className="cursor-hover h-7 w-7 grid place-items-center rounded-full border border-primary/30 text-gold hover:bg-primary/10"
                          aria-label="Increase"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                        <button
                          onClick={() => remove(dish.id)}
                          className="cursor-hover ml-auto h-7 w-7 grid place-items-center rounded-full text-muted-foreground hover:text-destructive transition-colors"
                          aria-label="Remove"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                    <p className="font-display text-base text-gradient-gold shrink-0">
                      {dish.price * qty}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {lines.length > 0 && (
            <div className="border-t border-primary/15 bg-background/95 backdrop-blur-md px-6 py-4 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{tr("cartSubtotal")}</span>
                <span className="font-display text-2xl text-gradient-gold">
                  {subtotal} <span className="text-sm">{lang === "ar" ? "ج.م" : "EGP"}</span>
                </span>
              </div>
              <p className="text-[11px] text-muted-foreground">{tr("cartDeliveryNote")}</p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={clear}
                  className="cursor-hover border-primary/30 text-muted-foreground hover:text-destructive hover:border-destructive/40"
                >
                  {tr("cartClear")}
                </Button>
                <Button
                  onClick={() => { setOpen(false); setCheckoutOpen(true); }}
                  className="cursor-hover flex-1 bg-gradient-gold text-primary-foreground font-semibold shadow-gold hover:scale-[1.02] transition-transform"
                >
                  {tr("cartCheckout")}
                </Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>

      <CheckoutDialog open={checkoutOpen} onOpenChange={setCheckoutOpen} />
    </>
  );
}
