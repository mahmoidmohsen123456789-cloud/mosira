// Menu section with category filter + ultra-3D tilt cards
import { useState, useRef, MouseEvent } from "react";
import { dishes, categories, Category, Dish } from "@/data/menu";
import { useLang } from "@/contexts/LanguageContext";
import { useCart } from "@/contexts/CartContext";
import { Plus } from "lucide-react";

function DishCard({ dish }: { dish: Dish }) {
  const ref = useRef<HTMLDivElement>(null);
  const { lang, tr } = useLang();
  const { add } = useCart();

  const onMove = (e: MouseEvent) => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    ref.current.style.transform = `rotateY(${px * 12}deg) rotateX(${-py * 12}deg) translateZ(20px)`;
  };
  const onLeave = () => {
    if (ref.current) ref.current.style.transform = "rotateY(0) rotateX(0) translateZ(0)";
  };

  const name = lang === "ar" ? dish.nameAr : dish.nameEn;
  const desc = lang === "ar" ? dish.descAr : dish.descEn;

  return (
    <div className="perspective-1000 group cursor-hover">
      <div
        ref={ref}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        className="preserve-3d relative overflow-hidden rounded-2xl border border-primary/20 bg-card shadow-rim transition-transform duration-300 ease-out"
      >
        <div className="relative aspect-square overflow-hidden bg-black">
          <img
            src={dish.image}
            alt={name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
            style={{ transform: "translateZ(40px)" }}
          />
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
               style={{ background: "radial-gradient(circle at center, transparent 50%, hsl(var(--primary) / 0.25) 100%)" }} />
          <div className="absolute top-3 right-3 rounded-full bg-background/90 backdrop-blur-md border border-primary/40 px-3 py-1 text-xs font-semibold text-gold">
            {dish.pieces} {lang === "ar" ? (dish.pieces > 1 ? "قطع" : "قطعة") : "pcs"}
          </div>
        </div>

        <div className="p-5 space-y-3">
          <div>
            <h3 className="font-display text-xl text-foreground leading-tight">{name}</h3>
            <p className="text-xs text-muted-foreground mt-0.5" dir={lang === "ar" ? "ltr" : "rtl"}>
              {lang === "ar" ? dish.nameEn : dish.nameAr}
            </p>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2">{desc}</p>
          <div className="flex items-center justify-between pt-2">
            <span className="font-display text-2xl text-gradient-gold">
              {dish.price} <span className="text-sm">{lang === "ar" ? "ج.م" : "EGP"}</span>
            </span>
            <button
              onClick={(e) => { e.stopPropagation(); add(dish); }}
              className="cursor-hover inline-flex items-center gap-1.5 rounded-full bg-gradient-gold text-primary-foreground text-xs font-semibold px-3 py-1.5 shadow-gold hover:scale-105 transition-transform"
              aria-label={tr("addToCart")}
            >
              <Plus className="h-3.5 w-3.5" /> {tr("addToCart")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function MenuSection() {
  const [active, setActive] = useState<Category>("all");
  const { lang } = useLang();
  const filtered = active === "all" ? dishes : dishes.filter((d) => d.category === active);

  return (
    <section id="menu" className="relative py-24 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <p className="font-display text-xs tracking-[0.4em] text-primary/70 uppercase mb-2" dir="ltr">The Menu · 献立</p>
          <h2 className="font-display text-5xl md:text-6xl text-gradient-gold mb-3">
            {lang === "ar" ? "قائمة الطعام" : "Our Menu"}
          </h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            {lang === "ar"
              ? "اختر طبقك من تشكيلة موري سوشي الفاخرة، طازج يومياً"
              : "Hand-crafted daily from the finest ingredients at Mori Sushi"}
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setActive(c.id)}
              className={`cursor-hover px-5 py-2 rounded-full text-sm font-medium transition-all border ${
                active === c.id
                  ? "bg-gradient-gold text-primary-foreground border-transparent shadow-gold"
                  : "border-primary/30 text-foreground/80 hover:border-primary hover:text-gold"
              }`}
            >
              {lang === "ar" ? c.labelAr : c.labelEn}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filtered.map((d) => <DishCard key={d.id} dish={d} />)}
        </div>
      </div>
    </section>
  );
}
