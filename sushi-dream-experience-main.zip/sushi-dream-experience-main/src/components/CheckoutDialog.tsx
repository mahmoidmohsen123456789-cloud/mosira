// Checkout — customer details + 3 payment methods (Cash, Card on Delivery, InstaPay screenshot)
import { useState } from "react";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useCart } from "@/contexts/CartContext";
import { useLang } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Banknote, CreditCard, Smartphone, Upload, Loader2, CheckCircle2 } from "lucide-react";

const WHATSAPP_NUMBER = "201208888492"; // 01208888492 with EG country code
const INSTAPAY_HANDLE = "MORI_INSTAPAY_HANDLE"; // TODO: replace with real handle

type PayMethod = "cash" | "card-delivery" | "instapay";

const schema = z.object({
  name: z.string().trim().min(2, "Name too short").max(80),
  phone: z.string().trim().min(7, "Invalid phone").max(20),
  address: z.string().trim().min(5, "Address too short").max(300),
  notes: z.string().trim().max(300).optional(),
});

export default function CheckoutDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const { lines, subtotal, clear } = useCart();
  const { lang, tr } = useLang();
  const [method, setMethod] = useState<PayMethod>("cash");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const isAr = lang === "ar";

  const reset = () => {
    setName(""); setPhone(""); setAddress(""); setNotes(""); setFile(null); setMethod("cash");
  };

  const buildOrderText = (screenshotUrl?: string) => {
    const items = lines.map((l) => `• ${isAr ? l.dish.nameAr : l.dish.nameEn} ×${l.qty} = ${l.dish.price * l.qty} ${isAr ? "ج.م" : "EGP"}`).join("\n");
    const methodLabel = method === "cash" ? (isAr ? "كاش عند الاستلام" : "Cash on Delivery")
      : method === "card-delivery" ? (isAr ? "بطاقة عند الاستلام" : "Card on Delivery")
      : "InstaPay";
    const header = isAr ? "🍣 طلب جديد من موري سوشي" : "🍣 New Mori Sushi Order";
    return [
      header,
      "",
      `${isAr ? "الاسم" : "Name"}: ${name}`,
      `${isAr ? "الهاتف" : "Phone"}: ${phone}`,
      `${isAr ? "العنوان" : "Address"}: ${address}`,
      notes ? `${isAr ? "ملاحظات" : "Notes"}: ${notes}` : null,
      "",
      isAr ? "— الطلب —" : "— Order —",
      items,
      "",
      `${isAr ? "الإجمالي" : "Total"}: ${subtotal} ${isAr ? "ج.م" : "EGP"}`,
      `${isAr ? "طريقة الدفع" : "Payment"}: ${methodLabel}`,
      screenshotUrl ? `${isAr ? "إثبات التحويل" : "Transfer screenshot"}: ${screenshotUrl}` : null,
    ].filter(Boolean).join("\n");
  };

  const submit = async () => {
    const parsed = schema.safeParse({ name, phone, address, notes });
    if (!parsed.success) {
      const first = Object.values(parsed.error.flatten().fieldErrors)[0]?.[0];
      toast({ title: isAr ? "تحقق من البيانات" : "Check your details", description: first, variant: "destructive" });
      return;
    }
    if (lines.length === 0) {
      toast({ title: isAr ? "السلة فارغة" : "Cart is empty", variant: "destructive" });
      return;
    }
    if (method === "instapay" && !file) {
      toast({ title: isAr ? "حمّل لقطة التحويل" : "Upload your transfer screenshot", variant: "destructive" });
      return;
    }

    setSubmitting(true);
    try {
      let screenshotUrl: string | undefined;
      if (method === "instapay" && file) {
        const ext = file.name.split(".").pop()?.toLowerCase() || "png";
        const path = `${crypto.randomUUID()}.${ext}`;
        const { error } = await supabase.storage.from("instapay-screenshots").upload(path, file, {
          contentType: file.type,
          upsert: false,
        });
        if (error) throw error;
        const { data } = supabase.storage.from("instapay-screenshots").getPublicUrl(path);
        screenshotUrl = data.publicUrl;
      }

      const text = buildOrderText(screenshotUrl);
      const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
      window.open(url, "_blank", "noopener,noreferrer");

      toast({
        title: isAr ? "تم إرسال الطلب" : "Order sent",
        description: isAr ? "أكّد طلبك في واتساب" : "Confirm your order on WhatsApp",
      });
      clear();
      reset();
      onOpenChange(false);
    } catch (e: any) {
      toast({ title: isAr ? "حدث خطأ" : "Something went wrong", description: e.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto bg-background border-primary/30">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl text-gradient-gold">{tr("checkoutTitle")}</DialogTitle>
          <DialogDescription>{tr("checkoutDesc")}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {/* Customer fields */}
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <Label htmlFor="co-name">{tr("fullName")}</Label>
              <Input id="co-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />
            </div>
            <div>
              <Label htmlFor="co-phone">{tr("phone")}</Label>
              <Input id="co-phone" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={20} dir="ltr" />
            </div>
            <div>
              <Label htmlFor="co-notes">{tr("notes")}</Label>
              <Input id="co-notes" value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={120} />
            </div>
            <div className="col-span-2">
              <Label htmlFor="co-addr">{tr("address")}</Label>
              <Textarea id="co-addr" value={address} onChange={(e) => setAddress(e.target.value)} rows={2} maxLength={300} />
            </div>
          </div>

          {/* Payment methods */}
          <div>
            <Label className="mb-2 block">{tr("payMethod")}</Label>
            <div className="grid grid-cols-3 gap-2">
              {([
                { id: "cash" as const, icon: Banknote, label: tr("payCash") },
                { id: "card-delivery" as const, icon: CreditCard, label: tr("payCardDelivery") },
                { id: "instapay" as const, icon: Smartphone, label: "InstaPay" },
              ]).map(({ id, icon: Icon, label }) => (
                <button
                  key={id}
                  onClick={() => setMethod(id)}
                  className={`cursor-hover relative rounded-xl border p-3 text-center transition-all ${
                    method === id
                      ? "border-primary bg-primary/10 shadow-gold"
                      : "border-primary/20 hover:border-primary/50 text-foreground/80"
                  }`}
                >
                  <Icon className={`h-5 w-5 mx-auto mb-1 ${method === id ? "text-gold" : "text-foreground/60"}`} />
                  <p className="text-xs font-medium">{label}</p>
                  {method === id && <CheckCircle2 className="absolute top-1.5 right-1.5 h-3.5 w-3.5 text-gold" />}
                </button>
              ))}
            </div>
          </div>

          {/* InstaPay-specific fields */}
          {method === "instapay" && (
            <div className="rounded-xl border border-primary/30 bg-primary/5 p-4 space-y-3 animate-fade-in">
              <div className="text-sm space-y-1">
                <p className="text-foreground/85">
                  {isAr
                    ? "حوّل المبلغ على إنستا باي ثم ارفع لقطة شاشة التحويل."
                    : "Send the amount via InstaPay, then upload your transfer screenshot."}
                </p>
                <div className="flex items-center justify-between rounded-lg bg-background/60 px-3 py-2 mt-2">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">InstaPay</p>
                    <p className="font-mono text-sm text-gold" dir="ltr">{INSTAPAY_HANDLE}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{tr("amount")}</p>
                    <p className="font-display text-lg text-gradient-gold">{subtotal} {isAr ? "ج.م" : "EGP"}</p>
                  </div>
                </div>
              </div>
              <div>
                <Label htmlFor="co-file" className="cursor-hover flex items-center justify-center gap-2 rounded-lg border-2 border-dashed border-primary/40 hover:border-primary/70 px-4 py-6 text-sm text-foreground/80 hover:bg-primary/5 transition-colors">
                  <Upload className="h-4 w-4 text-gold" />
                  {file ? file.name : tr("uploadScreenshot")}
                </Label>
                <input
                  id="co-file"
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/heic"
                  className="sr-only"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f && f.size > 5 * 1024 * 1024) {
                      toast({ title: isAr ? "حجم الصورة كبير" : "Image too large", description: "Max 5 MB", variant: "destructive" });
                      return;
                    }
                    setFile(f || null);
                  }}
                />
              </div>
            </div>
          )}

          {/* Total summary */}
          <div className="flex items-center justify-between border-t border-primary/15 pt-3">
            <span className="text-sm text-muted-foreground">{tr("cartSubtotal")}</span>
            <span className="font-display text-2xl text-gradient-gold">
              {subtotal} <span className="text-sm">{isAr ? "ج.م" : "EGP"}</span>
            </span>
          </div>

          <Button
            onClick={submit}
            disabled={submitting}
            className="cursor-hover w-full bg-gradient-gold text-primary-foreground font-semibold shadow-gold hover:scale-[1.02] transition-transform"
          >
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : tr("placeOrder")}
          </Button>
          <p className="text-[10px] text-center text-muted-foreground">{tr("whatsappConfirmNote")}</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
