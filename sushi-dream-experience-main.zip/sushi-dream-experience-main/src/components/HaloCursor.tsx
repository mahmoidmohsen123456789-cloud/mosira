// Custom golden halo cursor with smooth lag + hover expand + breathing pulse
import { useEffect, useRef } from "react";

export default function HaloCursor() {
  const ringRef = useRef<HTMLDivElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);
  const pos = useRef({ x: 0, y: 0 });
  const target = useRef({ x: 0, y: 0 });
  const expanded = useRef(false);

  useEffect(() => {
    if (window.matchMedia("(pointer: coarse)").matches) return;

    const onMove = (e: MouseEvent) => {
      target.current.x = e.clientX;
      target.current.y = e.clientY;
      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%, -50%)`;
      }
    };

    const onOver = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      const interactive = t.closest("button, a, [role='button'], input, .cursor-hover");
      expanded.current = !!interactive;
      if (ringRef.current) {
        ringRef.current.dataset.expanded = interactive ? "true" : "false";
      }
    };

    let raf = 0;
    const tick = () => {
      pos.current.x += (target.current.x - pos.current.x) * 0.15;
      pos.current.y += (target.current.y - pos.current.y) * 0.15;
      if (ringRef.current) {
        ringRef.current.style.transform = `translate(${pos.current.x}px, ${pos.current.y}px) translate(-50%, -50%)`;
      }
      raf = requestAnimationFrame(tick);
    };
    tick();

    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseover", onOver);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseover", onOver);
    };
  }, []);

  return (
    <>
      <div
        ref={ringRef}
        data-expanded="false"
        className="pointer-events-none fixed top-0 left-0 z-[10000] h-10 w-10 rounded-full border-2 border-primary mix-blend-difference transition-[width,height,opacity] duration-300 data-[expanded=true]:h-20 data-[expanded=true]:w-20 data-[expanded=true]:opacity-70 hidden md:block"
        style={{
          boxShadow: "0 0 30px hsl(var(--primary) / 0.5), inset 0 0 10px hsl(var(--primary) / 0.3)",
          animation: "pulse-gold 2.5s ease-out infinite",
        }}
      />
      <div
        ref={dotRef}
        className="pointer-events-none fixed top-0 left-0 z-[10001] h-1.5 w-1.5 rounded-full bg-primary hidden md:block"
      />
    </>
  );
}
