// Floating cart button — fixed bottom-right, golden, with count badge
import { ShoppingBag } from "lucide-react";
import { useCart } from "@/contexts/CartContext";

export default function CartButton() {
  const { count, setOpen } = useCart();
  return (
    <button
      onClick={() => setOpen(true)}
      className="cursor-hover fixed bottom-6 right-6 z-40 h-14 w-14 md:h-16 md:w-16 rounded-full bg-gradient-gold text-primary-foreground shadow-gold grid place-items-center hover:scale-110 transition-transform group"
      aria-label="Open cart"
    >
      <ShoppingBag className="h-6 w-6" />
      {count > 0 && (
        <span className="absolute -top-1 -right-1 h-6 min-w-6 px-1.5 rounded-full bg-background border-2 border-primary text-gold text-xs font-bold grid place-items-center animate-scale-in">
          {count}
        </span>
      )}
      <span className="absolute inset-0 rounded-full ring-2 ring-primary/40 animate-ping opacity-0 group-hover:opacity-100" />
    </button>
  );
}
