// Reviews — real Google data, film-still styled cards
import { reviews, reviewTopics, ratingBreakdown } from "@/data/reviews";
import { Star, ThumbsUp, Share2, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";

function StarsRow({ n }: { n: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`h-4 w-4 ${i < n ? "fill-primary text-primary" : "text-muted-foreground/30"}`} />
      ))}
    </div>
  );
}

export default function ReviewsSection() {
  return (
    <section className="relative py-24 px-6 border-y border-primary/10 bg-gradient-to-b from-background via-secondary/30 to-background">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <p className="font-display text-xs tracking-[0.4em] text-primary/70 uppercase mb-2" dir="ltr">Client Comments · 評価</p>
          <h2 className="font-display text-5xl md:text-6xl text-gradient-gold mb-3">آراء ضيوفنا</h2>
        </div>

        {/* Stats card */}
        <div className="max-w-3xl mx-auto mb-12 rounded-2xl border border-primary/20 bg-card p-8 shadow-rim">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="text-center md:text-right">
              <div className="font-display text-7xl text-gradient-gold leading-none mb-2">4.6</div>
              <StarsRow n={5} />
              <p className="text-sm text-muted-foreground mt-2">عدد التعليقات: 1,832 على Google · $$$</p>
            </div>
            <div className="space-y-2">
              {ratingBreakdown.map((r) => (
                <div key={r.stars} className="flex items-center gap-3 text-sm">
                  <span className="text-gold w-3">{r.stars}</span>
                  <Star className="h-3 w-3 fill-primary text-primary" />
                  <div className="flex-1 h-1.5 rounded-full bg-secondary overflow-hidden">
                    <div className="h-full bg-gradient-gold" style={{ width: `${r.percent}%` }} />
                  </div>
                  <span className="text-muted-foreground w-8 text-right text-xs">{r.percent}%</span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mt-6 pt-6 border-t border-primary/10">
            {reviewTopics.map((t) => (
              <span key={t.label} className="px-3 py-1 rounded-full border border-primary/30 text-xs text-foreground/80">
                {t.label} <span className="text-gold">{t.count}</span>
              </span>
            ))}
            <span className="px-3 py-1 rounded-full border border-primary/30 text-xs text-muted-foreground">+6</span>
          </div>
        </div>

        {/* Featured reviews — film-still cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {reviews.map((r, i) => (
            <div
              key={r.name}
              className="cursor-hover relative rounded-2xl border border-primary/20 bg-card p-6 shadow-rim hover:border-primary/50 transition-colors animate-fade-in"
              style={{ animationDelay: `${i * 0.15}s`, opacity: 0 }}
            >
              {/* film still corner mark */}
              <div className="absolute top-3 left-3 text-[10px] tracking-widest text-primary/40 font-mono" dir="ltr">
                STILL · 0{i + 1}
              </div>

              <div className="flex items-center gap-3 mb-4 mt-3">
                <div className="h-12 w-12 rounded-full bg-gradient-gold flex items-center justify-center font-display text-lg text-primary-foreground">
                  {r.initial}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{r.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{r.meta}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 mb-3">
                <StarsRow n={r.rating} />
                <span className="text-xs text-muted-foreground">· {r.time}</span>
              </div>

              <p className="text-sm text-foreground/80 leading-relaxed mb-4 line-clamp-6">{r.text}</p>

              <div className="flex items-center gap-4 text-xs text-muted-foreground pt-3 border-t border-primary/10">
                {r.photos && (
                  <span className="flex items-center gap-1"><Camera className="h-3 w-3" /> {r.photos}</span>
                )}
                {r.likes && (
                  <span className="flex items-center gap-1"><ThumbsUp className="h-3 w-3" /> {r.likes}</span>
                )}
                <button className="cursor-hover ml-auto flex items-center gap-1 hover:text-gold">
                  <Share2 className="h-3 w-3" /> مشاركة
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap justify-center gap-3">
          <Button asChild size="lg" className="bg-gradient-gold text-primary-foreground shadow-gold hover:scale-105 transition-transform">
            <a href="https://www.google.com/search?q=mori+sushi+open+air+mall+reviews" target="_blank" rel="noreferrer">كتابة مراجعة</a>
          </Button>
          <Button asChild variant="outline" size="lg" className="border-primary/40 text-foreground hover:bg-primary/10">
            <a href="https://www.google.com/search?q=mori+sushi+open+air+mall" target="_blank" rel="noreferrer">عرض جميع المراجعات (1,829+)</a>
          </Button>
        </div>
      </div>
    </section>
  );
}
