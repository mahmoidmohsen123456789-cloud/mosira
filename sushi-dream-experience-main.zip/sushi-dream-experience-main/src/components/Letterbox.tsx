// Letterbox cinema bars — slide away on scroll
import { useEffect, useState } from "react";

export default function Letterbox() {
  const [shrunk, setShrunk] = useState(false);
  useEffect(() => {
    const onScroll = () => setShrunk(window.scrollY > 100);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const h = shrunk ? "0" : "6vh";
  return (
    <>
      <div
        className="fixed top-0 left-0 right-0 z-[9990] bg-black pointer-events-none transition-[height] duration-700 ease-out"
        style={{ height: h }}
      />
      <div
        className="fixed bottom-0 left-0 right-0 z-[9990] bg-black pointer-events-none transition-[height] duration-700 ease-out"
        style={{ height: h }}
      />
    </>
  );
}
