// Executive Chef section
import chefImg from "@/assets/chef.jpg";
import { useLang } from "@/contexts/LanguageContext";
import { Award } from "lucide-react";

export default function ChefSection() {
  const { tr, lang } = useLang();

  const stats = [
    { n: "18+", label: tr("chefStat1") },
    { n: "40+", label: tr("chefStat2") },
    { n: "東京", label: tr("chefStat3") },
  ];

  return (
    <section id="chef" className="relative py-24 px-6 border-y border-primary/10 overflow-hidden">
      {/* Backdrop kanji */}
      <span className="absolute -right-10 top-1/2 -translate-y-1/2 font-display text-[26rem] text-primary/[0.04] pointer-events-none select-none leading-none" dir="ltr">
        料理長
      </span>

      <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center relative">
        {/* Portrait */}
        <div className="relative aspect-[4/5] max-w-md mx-auto md:mx-0 rounded-2xl overflow-hidden border border-primary/20 shadow-rim">
          <img
            src={chefImg}
            alt={lang === "en" ? "Executive Chef Hiroshi Tanaka" : "الشيف التنفيذي هيروشي تاناكا"}
            loading="lazy"
            width={1024}
            height={1280}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
          <div className="absolute bottom-0 inset-x-0 p-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-background/70 backdrop-blur border border-primary/30 text-xs text-gold mb-2">
              <Award className="h-3.5 w-3.5" /> {tr("chefKicker")}
            </div>
            <p className="font-display text-2xl text-foreground">{tr("chefName")}</p>
          </div>
        </div>

        {/* Text */}
        <div className="space-y-6">
          <p className="font-display text-xs tracking-[0.4em] text-primary/70 uppercase" dir="ltr">{tr("chefKicker")}</p>
          <h2 className="font-display text-5xl md:text-6xl text-gradient-gold leading-tight">
            {tr("chefName")}
          </h2>
          <p className="text-muted-foreground leading-relaxed text-lg">
            {tr("chefBio")}
          </p>

          <div className="grid grid-cols-3 gap-4 pt-4">
            {stats.map((s) => (
              <div key={s.label} className="text-center p-4 rounded-xl border border-primary/15 bg-card/50">
                <p className="font-display text-3xl text-gradient-gold">{s.n}</p>
                <p className="text-[11px] text-muted-foreground mt-1 tracking-wider uppercase">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
