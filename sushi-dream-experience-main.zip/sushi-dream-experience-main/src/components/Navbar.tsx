// Top navigation — logo, menu links, reserve/contact, language switcher
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useLang } from "@/contexts/LanguageContext";
import ReservationDialog from "@/components/ReservationDialog";
import { Globe, Menu as MenuIcon, X, Phone } from "lucide-react";

const SECTIONS = [
  { id: "home", key: "navHome" as const },
  { id: "menu", key: "navMenu" as const },
  { id: "chef", key: "navChef" as const },
  { id: "about", key: "navAbout" as const },
  { id: "gallery", key: "navGallery" as const },
  { id: "reviews", key: "navReviews" as const },
  { id: "location", key: "navLocation" as const },
];

export default function Navbar() {
  const { lang, setLang, tr } = useLang();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [reserveOpen, setReserveOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (id: string) => {
    setMobileOpen(false);
    if (id === "home") return window.scrollTo({ top: 0, behavior: "smooth" });
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <header
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
          scrolled
            ? "bg-background/85 backdrop-blur-xl border-b border-primary/20 shadow-deep"
            : "bg-gradient-to-b from-background/80 to-transparent"
        }`}
      >
        <div className="container mx-auto px-4 md:px-6 h-16 md:h-20 flex items-center justify-between gap-4">
          {/* Logo */}
          <button onClick={() => go("home")} className="cursor-hover flex items-center gap-2 shrink-0">
            <span className="font-display text-2xl md:text-3xl text-gradient-gold leading-none">森</span>
            <div className="hidden sm:block leading-tight text-left">
              <p className="font-display text-sm md:text-base tracking-[0.25em] text-foreground" dir="ltr">MORI SUSHI</p>
              <p className="text-[10px] tracking-[0.3em] text-primary/70 uppercase" dir="ltr">Open Air Mall</p>
            </div>
          </button>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {SECTIONS.map((s) => (
              <button
                key={s.id}
                onClick={() => go(s.id)}
                className="cursor-hover px-3 py-2 text-sm text-foreground/75 hover:text-gold transition-colors relative group"
              >
                {tr(s.key)}
                <span className="absolute left-1/2 -translate-x-1/2 bottom-1 w-0 h-px bg-gold transition-all group-hover:w-2/3" />
              </button>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <a
              href="tel:+201208888492"
              className="cursor-hover hidden md:inline-flex items-center gap-2 text-xs text-foreground/70 hover:text-gold transition-colors px-2"
              dir="ltr"
            >
              <Phone className="h-3.5 w-3.5" /> 012 0888 8492
            </a>

            {/* Language switcher */}
            <div className="cursor-hover hidden sm:flex items-center rounded-full border border-primary/30 overflow-hidden text-xs">
              <button
                onClick={() => setLang("en")}
                className={`px-2.5 py-1 transition-colors ${lang === "en" ? "bg-gradient-gold text-primary-foreground font-semibold" : "text-foreground/70 hover:text-gold"}`}
              >
                EN
              </button>
              <button
                onClick={() => setLang("ar")}
                className={`px-2.5 py-1 transition-colors ${lang === "ar" ? "bg-gradient-gold text-primary-foreground font-semibold" : "text-foreground/70 hover:text-gold"}`}
              >
                AR
              </button>
            </div>

            <Button
              onClick={() => setReserveOpen(true)}
              size="sm"
              className="cursor-hover bg-gradient-gold text-primary-foreground font-semibold shadow-gold hover:scale-[1.04] transition-transform"
            >
              {tr("reserve")}
            </Button>

            {/* Mobile toggle */}
            <button
              onClick={() => setMobileOpen((o) => !o)}
              className="cursor-hover lg:hidden h-9 w-9 grid place-items-center rounded-full border border-primary/30 text-gold"
              aria-label="Menu"
            >
              {mobileOpen ? <X className="h-4 w-4" /> : <MenuIcon className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {/* Mobile drawer */}
        {mobileOpen && (
          <div className="lg:hidden border-t border-primary/15 bg-background/95 backdrop-blur-xl">
            <nav className="container mx-auto px-6 py-4 flex flex-col">
              {SECTIONS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => go(s.id)}
                  className="text-start py-3 border-b border-primary/10 text-foreground/80 hover:text-gold transition-colors"
                >
                  {tr(s.key)}
                </button>
              ))}
              <div className="flex items-center justify-between gap-3 pt-4">
                <div className="flex items-center rounded-full border border-primary/30 overflow-hidden text-xs">
                  <button onClick={() => setLang("en")} className={`px-3 py-1.5 ${lang === "en" ? "bg-gradient-gold text-primary-foreground font-semibold" : "text-foreground/70"}`}>EN</button>
                  <button onClick={() => setLang("ar")} className={`px-3 py-1.5 ${lang === "ar" ? "bg-gradient-gold text-primary-foreground font-semibold" : "text-foreground/70"}`}>AR</button>
                </div>
                <Button onClick={() => { setMobileOpen(false); setReserveOpen(true); }} size="sm" className="bg-gradient-gold text-primary-foreground font-semibold">
                  {tr("reserve")}
                </Button>
              </div>
            </nav>
          </div>
        )}
      </header>

      <ReservationDialog open={reserveOpen} onOpenChange={setReserveOpen} />
    </>
  );
}
