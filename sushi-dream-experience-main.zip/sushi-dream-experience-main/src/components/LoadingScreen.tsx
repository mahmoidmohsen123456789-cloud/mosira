// Cinematic loading screen — "Your plate is being prepared..."
import { useEffect, useState } from "react";

export default function LoadingScreen({ onDone }: { onDone: () => void }) {
  const [hide, setHide] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setHide(true), 2200);
    const t2 = setTimeout(onDone, 2800);
    return () => { clearTimeout(t); clearTimeout(t2); };
  }, [onDone]);

  return (
    <div
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-background transition-opacity duration-700 ${
        hide ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      <div className="relative mb-8">
        <div className="absolute inset-0 rounded-full border-2 border-primary/30 animate-ping" />
        <div className="relative h-24 w-24 rounded-full border-2 border-primary flex items-center justify-center font-display text-3xl text-gold">
          森
        </div>
      </div>
      <p className="font-display text-xs tracking-[0.4em] text-primary/80 uppercase mb-2" dir="ltr">
        Your plate is being prepared
      </p>
      <p className="font-display text-2xl text-gradient-gold tracking-widest" dir="ltr">
        MORI SUSHI
      </p>
    </div>
  );
}
