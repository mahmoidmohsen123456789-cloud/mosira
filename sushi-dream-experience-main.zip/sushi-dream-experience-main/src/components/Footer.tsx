// Footer
export default function Footer() {
  return (
    <footer className="border-t border-primary/15 py-10 px-6 text-center">
      <div className="container mx-auto space-y-3">
        <p className="font-display text-3xl text-gradient-gold">森 Mori Sushi</p>
        <p className="text-xs text-muted-foreground" dir="ltr">A Film by the Chefs of New Cairo · Open Air Mall</p>
        <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Mori Sushi. جميع الحقوق محفوظة.</p>
      </div>
    </footer>
  );
}
