// About / Story section
export default function AboutSection() {
  return (
    <section className="relative py-24 px-6 border-y border-primary/10">
      <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <p className="font-display text-xs tracking-[0.4em] text-primary/70 uppercase" dir="ltr">Our Story · 物語</p>
          <h2 className="font-display text-5xl md:text-6xl text-gradient-gold leading-tight">
            حرفة يابانية<br/>في قلب القاهرة
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            في موري سوشي، نحضّر كل قطعة بأيدي شيفات يابانيين متخصصين، باستخدام أجود أنواع السمك الطازج يومياً. من الماكي الكلاسيكي إلى أطباق الشيف المبتكرة، نقدم تجربة سوشي حقيقية تعكس روح الفن الياباني.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            أكثر من <span className="text-gold font-semibold">1,832 ضيف</span> منحونا تقييم <span className="text-gold font-semibold">4.6 نجوم</span> على Google. لأن الجودة تتكلم بنفسها.
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            {["طازج يومياً", "شيف ياباني", "أجواء فاخرة", "خدمة مميزة"].map((t) => (
              <span key={t} className="px-4 py-1.5 rounded-full border border-primary/30 text-sm text-foreground/80">{t}</span>
            ))}
          </div>
        </div>

        <div className="relative aspect-[4/5] rounded-2xl overflow-hidden border border-primary/20 shadow-rim">
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="font-display text-[18rem] text-primary/10 leading-none">森</span>
          </div>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-8">
            <p className="font-display text-7xl text-gradient-gold mb-2">10+</p>
            <p className="text-sm text-muted-foreground tracking-widest uppercase" dir="ltr">Years of Mastery</p>
            <div className="w-12 h-px bg-primary/40 my-6" />
            <p className="font-display text-3xl text-foreground/90">"شغف · إتقان · بساطة"</p>
          </div>
        </div>
      </div>
    </section>
  );
}
