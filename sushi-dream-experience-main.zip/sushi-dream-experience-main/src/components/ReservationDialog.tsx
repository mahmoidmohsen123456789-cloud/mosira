// Reservation dialog — sends via WhatsApp
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useLang } from "@/contexts/LanguageContext";
import { CalendarDays } from "lucide-react";

const PHONE = "201208888492";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
}

export default function ReservationDialog({ open, onOpenChange }: Props) {
  const { tr, lang } = useLang();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("19:00");
  const [guests, setGuests] = useState("2");
  const [notes, setNotes] = useState("");

  const handleSend = () => {
    const msg =
      lang === "ar"
        ? `مرحباً Mori Sushi، أود حجز طاولة:\n\nالاسم: ${name}\nالهاتف: ${phone}\nالتاريخ: ${date}\nالوقت: ${time}\nعدد الضيوف: ${guests}\nملاحظات: ${notes || "—"}`
        : `Hello Mori Sushi, I'd like to reserve a table:\n\nName: ${name}\nPhone: ${phone}\nDate: ${date}\nTime: ${time}\nGuests: ${guests}\nNotes: ${notes || "—"}`;
    window.open(`https://wa.me/${PHONE}?text=${encodeURIComponent(msg)}`, "_blank");
    onOpenChange(false);
  };

  const valid = name && phone && date;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-primary/30 max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl text-gradient-gold flex items-center gap-2">
            <CalendarDays className="h-5 w-5 text-gold" />
            {tr("reserveTitle")}
          </DialogTitle>
          <DialogDescription>{tr("reserveDesc")}</DialogDescription>
        </DialogHeader>

        <div className="space-y-3 mt-2">
          <div className="space-y-1.5">
            <Label className="text-xs">{tr("fullName")}</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} className="bg-background border-primary/20" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">{tr("phone")}</Label>
            <Input value={phone} onChange={(e) => setPhone(e.target.value)} type="tel" className="bg-background border-primary/20" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">{tr("date")}</Label>
              <Input value={date} onChange={(e) => setDate(e.target.value)} type="date" className="bg-background border-primary/20" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">{tr("time")}</Label>
              <Input value={time} onChange={(e) => setTime(e.target.value)} type="time" className="bg-background border-primary/20" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">{tr("guests")}</Label>
            <Input value={guests} onChange={(e) => setGuests(e.target.value)} type="number" min={1} max={20} className="bg-background border-primary/20" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">{tr("notes")}</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} className="bg-background border-primary/20" />
          </div>

          <Button
            onClick={handleSend}
            disabled={!valid}
            size="lg"
            className="w-full bg-gradient-gold text-primary-foreground font-semibold shadow-gold hover:scale-[1.02] transition-transform mt-2"
          >
            {tr("sendReservation")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
