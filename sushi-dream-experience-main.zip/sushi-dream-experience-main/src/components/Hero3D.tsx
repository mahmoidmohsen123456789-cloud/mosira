// Cinematic 3D hero — rotating sushi carousel with shot cuts + postprocessing
// WebGL fallback to interior image
import { Canvas, useFrame, useLoader } from "@react-three/fiber";
import { Suspense, useMemo, useRef, useState, useEffect } from "react";
import * as THREE from "three";
import { TextureLoader } from "three";
import { EffectComposer, Vignette, ChromaticAberration, Bloom, DepthOfField } from "@react-three/postprocessing";
import { BlendFunction } from "postprocessing";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import interior from "@/assets/interior.jpg";

import maki from "@/assets/dish-maki-combo.jpg";
import combo from "@/assets/dish-sushi-combo.jpg";
import salmonNigiri from "@/assets/dish-salmon-nigiri.jpg";
import tunaNigiri from "@/assets/dish-tuna-nigiri.jpg";
import sashimi from "@/assets/dish-sashimi.jpg";
import dragon from "@/assets/dish-dragon-roll.jpg";
import california from "@/assets/dish-california.jpg";
import spicyTuna from "@/assets/dish-spicy-tuna.jpg";
import tempura from "@/assets/dish-tempura.jpg";
import teriyaki from "@/assets/dish-teriyaki.jpg";

const PLATE_IMAGES = [maki, combo, salmonNigiri, tunaNigiri, sashimi, dragon, california, spicyTuna, tempura, teriyaki];

// One sushi plate as a textured disc with subtle thickness
function Plate({ index, total, image }: { index: number; total: number; image: string }) {
  const ref = useRef<THREE.Group>(null);
  const texture = useLoader(TextureLoader, image);
  const angle = (index / total) * Math.PI * 2;
  const radius = 4;

  useFrame((state) => {
    if (!ref.current) return;
    // gentle bob per plate
    ref.current.position.y = Math.sin(state.clock.elapsedTime * 1.2 + index) * 0.08;
  });

  return (
    <group
      ref={ref}
      position={[Math.cos(angle) * radius, 0, Math.sin(angle) * radius]}
      rotation={[-Math.PI / 2.5, 0, -angle + Math.PI / 2]}
    >
      {/* plate disc */}
      <mesh castShadow receiveShadow>
        <cylinderGeometry args={[1.1, 1.1, 0.08, 64]} />
        <meshStandardMaterial color="#0a0a0a" metalness={0.4} roughness={0.6} />
      </mesh>
      {/* dish texture on top */}
      <mesh position={[0, 0.045, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[1.05, 64]} />
        <meshStandardMaterial map={texture} roughness={0.45} metalness={0.1} />
      </mesh>
      {/* gold rim */}
      <mesh position={[0, 0, 0]}>
        <torusGeometry args={[1.1, 0.015, 16, 64]} />
        <meshStandardMaterial color="#D4A853" metalness={1} roughness={0.25} emissive="#D4A853" emissiveIntensity={0.3} />
      </mesh>
    </group>
  );
}

// Rotating carousel of plates
function Carousel() {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation.y += dt * 0.15;
  });
  return (
    <group ref={ref}>
      {PLATE_IMAGES.map((img, i) => (
        <Plate key={i} index={i} total={PLATE_IMAGES.length} image={img} />
      ))}
    </group>
  );
}

// 50 floating golden particles
function Particles() {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const arr = new Float32Array(50 * 3);
    for (let i = 0; i < 50; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 18;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 10;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 18;
    }
    return arr;
  }, []);

  useFrame((state) => {
    if (!ref.current) return;
    const time = state.clock.elapsedTime;
    const arr = ref.current.geometry.attributes.position.array as Float32Array;
    for (let i = 0; i < 50; i++) {
      arr[i * 3 + 1] += Math.sin(time + i) * 0.002;
    }
    ref.current.geometry.attributes.position.needsUpdate = true;
    ref.current.rotation.y = time * 0.02;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={50} array={positions} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial
        size={0.08}
        color="#D4A853"
        transparent
        opacity={0.9}
        sizeAttenuation
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

// Camera "shot list" — cuts every 6 seconds between cinematic framings
const SHOTS: { pos: [number, number, number]; look: [number, number, number] }[] = [
  { pos: [0, 2.5, 8],   look: [0, 0, 0] },   // wide establishing
  { pos: [3, 1.2, 5],   look: [0, 0, 0] },   // mid orbit
  { pos: [0, 7, 0.1],   look: [0, 0, 0] },   // top-down
  { pos: [-5, 0.8, 4],  look: [0, 0, 0] },   // dolly side
  { pos: [1.5, 0.4, 6.5], look: [0, 0.2, 0] }, // close-up
];

function ShotDirector() {
  const shotIdx = useRef(0);
  const t = useRef(0);
  const current = useRef({ ...SHOTS[0] });
  const target = useRef({ ...SHOTS[0] });

  useFrame((state, dt) => {
    t.current += dt;
    if (t.current > 6) {
      t.current = 0;
      shotIdx.current = (shotIdx.current + 1) % SHOTS.length;
      target.current = SHOTS[shotIdx.current];
    }
    // smooth lerp camera position + look-at
    const lerp = (a: number, b: number) => a + (b - a) * 0.025;
    current.current.pos = [
      lerp(current.current.pos[0], target.current.pos[0]),
      lerp(current.current.pos[1], target.current.pos[1]),
      lerp(current.current.pos[2], target.current.pos[2]),
    ];
    current.current.look = [
      lerp(current.current.look[0], target.current.look[0]),
      lerp(current.current.look[1], target.current.look[1]),
      lerp(current.current.look[2], target.current.look[2]),
    ];
    state.camera.position.set(...current.current.pos);
    state.camera.lookAt(...current.current.look);
  });
  return null;
}

function detectWebGL(): boolean {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl") || c.getContext("experimental-webgl"));
  } catch { return false; }
}

export default function Hero3D() {
  const [hasWebGL, setHasWebGL] = useState(true);
  useEffect(() => { setHasWebGL(detectWebGL()); }, []);

  const scrollToMenu = () => {
    document.getElementById("menu")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative h-screen w-full overflow-hidden">
      {/* 3D scene or fallback */}
      {hasWebGL ? (
        <Canvas
          shadows
          camera={{ position: [0, 2.5, 8], fov: 50 }}
          gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping }}
          className="absolute inset-0"
        >
          <fog attach="fog" args={["#0a0a0a", 6, 20]} />
          <color attach="background" args={["#0a0a0a"]} />
          <ambientLight intensity={0.25} color="#ffe4b5" />
          <directionalLight position={[5, 8, 5]} intensity={1.2} color="#D4A853" castShadow />
          <pointLight position={[-5, 3, -5]} intensity={0.8} color="#ff9966" />
          <pointLight position={[0, 4, 0]} intensity={0.6} color="#D4A853" />

          <Suspense fallback={null}>
            <Carousel />
            <Particles />
          </Suspense>

          <ShotDirector />

          <EffectComposer>
            <Bloom intensity={0.6} luminanceThreshold={0.6} luminanceSmoothing={0.4} mipmapBlur />
            <DepthOfField focusDistance={0.02} focalLength={0.05} bokehScale={3} />
            <ChromaticAberration offset={new THREE.Vector2(0.0008, 0.0012)} blendFunction={BlendFunction.NORMAL} radialModulation modulationOffset={0.2} />
            <Vignette eskil={false} offset={0.2} darkness={0.85} />
          </EffectComposer>
        </Canvas>
      ) : (
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${interior})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/40 to-background" />
        </div>
      )}

      {/* Cinematic gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/50 pointer-events-none" />

      {/* GIANT golden restaurant name banner — sits above the carousel */}
      <div className="absolute top-0 inset-x-0 z-20 pt-24 md:pt-28 pointer-events-none">
        <div className="text-center px-4">
          <p className="font-display text-[10px] md:text-xs tracking-[0.5em] text-primary/70 uppercase mb-2 animate-fade-in" dir="ltr">
            Open Air Mall · New Cairo
          </p>
          <h1
            className="font-display text-gradient-gold glow-gold leading-none animate-fade-in"
            style={{
              fontSize: "clamp(3.5rem, 14vw, 11rem)",
              letterSpacing: "0.02em",
              animationDelay: "0.1s",
              opacity: 0,
            }}
            dir="ltr"
          >
            MORI SUSHI
          </h1>
          <p
            className="font-display text-2xl md:text-4xl text-gold/90 mt-1 animate-fade-in"
            style={{ animationDelay: "0.3s", opacity: 0 }}
          >
            森 · 寿司
          </p>
        </div>
      </div>

      {/* Hero overlay content (rating + CTA) */}
      <div className="relative z-10 flex h-full flex-col items-center justify-end pb-32 px-6 text-center">
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-background/40 px-4 py-1.5 backdrop-blur-md animate-fade-in" style={{ animationDelay: "0.5s", opacity: 0 }}>
          <span className="text-gold text-sm">★ 4.6</span>
          <span className="text-xs text-muted-foreground" dir="ltr">· 1,832 reviews · $$$</span>
        </div>

        <p className="max-w-xl text-sm md:text-base text-muted-foreground mb-6 animate-fade-in" dir="ltr" style={{ animationDelay: "0.6s", opacity: 0 }}>
          A Film by the Chefs of New Cairo
        </p>

        <Button
          size="lg"
          onClick={scrollToMenu}
          className="bg-gradient-gold text-primary-foreground font-semibold shadow-gold hover:scale-105 transition-transform animate-fade-in"
          style={{ animationDelay: "0.8s", opacity: 0 }}
        >
          View Menu
        </Button>

        <button onClick={scrollToMenu} className="absolute bottom-6 animate-bounce text-primary/70" aria-label="scroll">
          <ChevronDown className="h-8 w-8" />
        </button>
      </div>
    </section>
  );
}
