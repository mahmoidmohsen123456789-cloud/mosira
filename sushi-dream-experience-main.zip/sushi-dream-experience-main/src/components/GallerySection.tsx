// Gallery — masonry-ish dish + ambience grid
import dish1 from "@/assets/dish-maki-combo.jpg";
import dish2 from "@/assets/dish-sushi-combo.jpg";
import dish3 from "@/assets/dish-salmon-nigiri.jpg";
import dish4 from "@/assets/dish-tuna-nigiri.jpg";
import dish5 from "@/assets/dish-sashimi.jpg";
import dish6 from "@/assets/dish-dragon-roll.jpg";
import dish7 from "@/assets/dish-california.jpg";
import dish8 from "@/assets/dish-spicy-tuna.jpg";
import dish9 from "@/assets/dish-teriyaki.jpg";
import interior from "@/assets/interior.jpg";

const galleryImages = [
  interior,
  dish1, dish2, dish3,
  dish4, dish5, dish6,
  dish7, dish8, dish9,
];

export default function GallerySection() {
  return (
    <section className="relative py-24 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <p className="font-display text-xs tracking-[0.4em] text-primary/70 uppercase mb-2" dir="ltr">Gallery · 写真</p>
          <h2 className="font-display text-5xl md:text-6xl text-gradient-gold mb-3">معرض الصور</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
          {galleryImages.map((src, i) => (
            <div
              key={i}
              className={`cursor-hover relative overflow-hidden rounded-xl border border-primary/15 group ${
                i === 0 ? "col-span-2 row-span-2 aspect-square" : "aspect-square"
              }`}
            >
              <img src={src} alt={`gallery ${i}`} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-60 group-hover:opacity-30 transition-opacity" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
