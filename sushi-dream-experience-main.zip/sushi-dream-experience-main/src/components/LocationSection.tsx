// Location & hours section with real Mori Sushi data
import { MapPin, Phone, Globe, Clock, Utensils } from "lucide-react";

const PEAK_HOURS = [
  { h: "٦ص", v: 5 },
  { h: "٩ص", v: 8 },
  { h: "١٢م", v: 35 },
  { h: "٣م", v: 50 },
  { h: "٦م", v: 75 },
  { h: "٩م", v: 95 },
];

const SERVICES = [
  "الطلب على الإنترنت",
  "الجلوس داخل المكان",
  "طعام سفري",
  "التسليم بدون تلامس",
];

export default function LocationSection() {
  // Compute live status (open 12pm - 1am)
  const now = new Date();
  const h = now.getHours();
  const isOpen = h >= 12 || h < 1;

  return (
    <section className="relative py-24 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <p className="font-display text-xs tracking-[0.4em] text-primary/70 uppercase mb-2" dir="ltr">Visit Us · 場所</p>
          <h2 className="font-display text-5xl md:text-6xl text-gradient-gold mb-3">الموقع والمواعيد</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Info card */}
          <div className="rounded-2xl border border-primary/20 bg-card p-8 shadow-rim space-y-6">
            <div className="flex items-center gap-3">
              <span className={`h-2.5 w-2.5 rounded-full ${isOpen ? "bg-primary" : "bg-destructive"} animate-pulse`} />
              <span className="font-semibold">
                {isOpen ? <span className="text-gold">مفتوح الآن</span> : <span className="text-destructive">مغلق</span>}
              </span>
              <span className="text-sm text-muted-foreground">· يفتح ١٢ م - ١ ص</span>
            </div>

            <div className="space-y-4">
              <div className="flex gap-3">
                <MapPin className="h-5 w-5 text-gold shrink-0 mt-1" />
                <div>
                  <p className="font-semibold">Food Hall — Open Air Mall</p>
                  <p className="text-sm text-muted-foreground">ثاني القاهرة الجديدة، محافظة القاهرة</p>
                  <p className="text-xs text-primary/60 mt-1 font-mono" dir="ltr">Plus code: 4J4G+MC</p>
                </div>
              </div>

              <a href="tel:+201208888492" className="cursor-hover flex gap-3 hover:text-gold transition-colors">
                <Phone className="h-5 w-5 text-gold shrink-0 mt-1" />
                <div>
                  <p className="font-semibold" dir="ltr">012 0888 8492</p>
                  <p className="text-sm text-muted-foreground">اضغط للاتصال</p>
                </div>
              </a>

              <a href="https://mori-sushi.com" target="_blank" rel="noreferrer" className="cursor-hover flex gap-3 hover:text-gold transition-colors">
                <Globe className="h-5 w-5 text-gold shrink-0 mt-1" />
                <div>
                  <p className="font-semibold" dir="ltr">mori-sushi.com</p>
                  <p className="text-sm text-muted-foreground">الموقع الإلكتروني</p>
                </div>
              </a>

              <div className="flex gap-3">
                <Utensils className="h-5 w-5 text-gold shrink-0 mt-1" />
                <div>
                  <p className="font-semibold">القائمة</p>
                  <a href="https://flexmenus.darwinz.ai" target="_blank" rel="noreferrer" className="cursor-hover text-sm text-muted-foreground hover:text-gold" dir="ltr">flexmenus.darwinz.ai</a>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 pt-4 border-t border-primary/10">
              {SERVICES.map((s) => (
                <span key={s} className="px-3 py-1 rounded-full border border-primary/30 text-xs text-foreground/80">{s}</span>
              ))}
            </div>
          </div>

          {/* Peak hours card */}
          <div className="rounded-2xl border border-primary/20 bg-card p-8 shadow-rim">
            <div className="flex items-center gap-2 mb-1">
              <Clock className="h-5 w-5 text-gold" />
              <h3 className="font-display text-2xl">أوقات الزحمة</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-6">أيام الأربعاء</p>

            <div className="flex items-end justify-between gap-2 h-40 mb-3">
              {PEAK_HOURS.map((p) => (
                <div key={p.h} className="flex-1 flex flex-col items-center gap-2">
                  <div
                    className="w-full rounded-t bg-gradient-to-t from-primary/40 to-primary"
                    style={{ height: `${p.v}%` }}
                  />
                </div>
              ))}
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              {PEAK_HOURS.map((p) => <span key={p.h}>{p.h}</span>)}
            </div>

            <div className="mt-8 pt-6 border-t border-primary/10">
              <p className="text-sm text-muted-foreground mb-3">المطعم على خرائط Google</p>
              <a
                href="https://www.google.com/maps/search/mori+sushi+open+air+mall"
                target="_blank"
                rel="noreferrer"
                className="cursor-hover inline-flex items-center gap-2 text-gold hover:underline"
              >
                <MapPin className="h-4 w-4" /> فتح في الخرائط
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
