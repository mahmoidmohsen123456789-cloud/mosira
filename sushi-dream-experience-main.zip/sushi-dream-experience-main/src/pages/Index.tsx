// Mori Sushi — Cinematic 3D luxury restaurant homepage
import { useEffect, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { CartProvider } from "@/contexts/CartContext";
import HaloCursor from "@/components/HaloCursor";
import Letterbox from "@/components/Letterbox";
import LoadingScreen from "@/components/LoadingScreen";
import Navbar from "@/components/Navbar";
import Hero3D from "@/components/Hero3D";
import AboutSection from "@/components/AboutSection";
import ChefSection from "@/components/ChefSection";
import MenuSection from "@/components/MenuSection";
import GallerySection from "@/components/GallerySection";
import ReviewsSection from "@/components/ReviewsSection";
import LocationSection from "@/components/LocationSection";
import Footer from "@/components/Footer";
import CartButton from "@/components/CartButton";
import CartPanel from "@/components/CartPanel";

gsap.registerPlugin(ScrollTrigger);

const Index = () => {
  const [loading, setLoading] = useState(true);

  // SEO
  useEffect(() => {
    document.title = "Mori Sushi — Cinematic Japanese Dining in Cairo | Open Air Mall";
    const desc = "Mori Sushi at Open Air Mall, New Cairo — a cinematic Japanese fine-dining experience. Order online via WhatsApp, reserve a table, or visit us.";
    let m = document.querySelector('meta[name="description"]');
    if (!m) {
      m = document.createElement("meta");
      m.setAttribute("name", "description");
      document.head.appendChild(m);
    }
    m.setAttribute("content", desc);

    let canon = document.querySelector('link[rel="canonical"]');
    if (!canon) {
      canon = document.createElement("link");
      canon.setAttribute("rel", "canonical");
      document.head.appendChild(canon);
    }
    canon.setAttribute("href", window.location.origin + "/");
  }, []);

  // GSAP scroll reveals
  useEffect(() => {
    if (loading) return;
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("section").forEach((sec) => {
        gsap.from(sec.querySelectorAll("h2, h3"), {
          y: 40, opacity: 0, duration: 1, ease: "power3.out",
          scrollTrigger: { trigger: sec, start: "top 80%" },
        });
      });
    });
    return () => ctx.revert();
  }, [loading]);

  return (
    <LanguageProvider>
      <CartProvider>
        <div className="relative film-grain vignette">
          {loading && <LoadingScreen onDone={() => setLoading(false)} />}
          <HaloCursor />
          <Letterbox />
          <Navbar />

          <main>
            <section id="home"><Hero3D /></section>
            <MenuSection />
            <div id="chef"><ChefSection /></div>
            <div id="about"><AboutSection /></div>
            <div id="gallery"><GallerySection /></div>
            <div id="reviews"><ReviewsSection /></div>
            <div id="location"><LocationSection /></div>
          </main>

          <Footer />
          <CartButton />
          <CartPanel />
        </div>
      </CartProvider>
    </LanguageProvider>
  );
};

export default Index;
