// Language context — English default, Arabic optional
import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type Lang = "en" | "ar";

type Dict = Record<string, { en: string; ar: string }>;

export const t: Dict = {
  // Nav
  navHome: { en: "Home", ar: "الرئيسية" },
  navMenu: { en: "Menu", ar: "القائمة" },
  navAbout: { en: "About", ar: "عن المطعم" },
  navChef: { en: "Chef", ar: "الشيف" },
  navGallery: { en: "Gallery", ar: "المعرض" },
  navReviews: { en: "Reviews", ar: "المراجعات" },
  navLocation: { en: "Location", ar: "الموقع" },
  reserve: { en: "Reserve", ar: "احجز طاولة" },
  contact: { en: "Contact", ar: "تواصل معنا" },
  // Reservation
  reserveTitle: { en: "Reserve a Table", ar: "احجز طاولة" },
  reserveDesc: { en: "We'll confirm your reservation via WhatsApp.", ar: "سنؤكد حجزك عبر واتساب." },
  fullName: { en: "Full name", ar: "الاسم بالكامل" },
  phone: { en: "Phone number", ar: "رقم الهاتف" },
  date: { en: "Date", ar: "التاريخ" },
  time: { en: "Time", ar: "الوقت" },
  guests: { en: "Guests", ar: "عدد الضيوف" },
  notes: { en: "Notes (optional)", ar: "ملاحظات (اختياري)" },
  sendReservation: { en: "Send via WhatsApp", ar: "إرسال عبر واتساب" },
  // Chef
  chefKicker: { en: "Executive Chef · 料理長", ar: "الشيف التنفيذي · 料理長" },
  chefName: { en: "Chef Hiroshi Tanaka", ar: "الشيف هيروشي تاناكا" },
  chefBio: {
    en: "Trained in Tokyo's finest sushi-ya for over 18 years, Chef Hiroshi brings the discipline of Edomae sushi to Cairo. Each cut, each grain of rice — a quiet act of devotion.",
    ar: "تدرّب الشيف هيروشي في أعرق مطاعم السوشي في طوكيو لأكثر من ١٨ عاماً، ليجلب انضباط سوشي إيدوماي إلى القاهرة. كل قطعة، كل حبة أرز — فعل صامت من الإخلاص.",
  },
  chefStat1: { en: "Years of Mastery", ar: "سنة من الإتقان" },
  chefStat2: { en: "Signature Dishes", ar: "طبق مميز" },
  chefStat3: { en: "Tokyo Trained", ar: "تدريب طوكيو" },
  // Cart & checkout
  addToCart: { en: "Add to cart", ar: "أضف للسلة" },
  cartTitle: { en: "Your Cart", ar: "سلتك" },
  cartEmpty: { en: "Your cart is empty", ar: "السلة فارغة" },
  cartSubtotal: { en: "Subtotal", ar: "الإجمالي" },
  cartDeliveryNote: { en: "Delivery fees calculated on WhatsApp confirmation.", ar: "رسوم التوصيل تُحسب عند تأكيد الطلب على واتساب." },
  cartClear: { en: "Clear", ar: "تفريغ" },
  cartCheckout: { en: "Checkout", ar: "إتمام الطلب" },
  checkoutTitle: { en: "Complete Your Order", ar: "إتمام الطلب" },
  checkoutDesc: { en: "We'll confirm your order via WhatsApp.", ar: "سنؤكد طلبك عبر واتساب." },
  address: { en: "Delivery address", ar: "عنوان التوصيل" },
  amount: { en: "Amount", ar: "المبلغ" },
  payMethod: { en: "Payment method", ar: "طريقة الدفع" },
  payCash: { en: "Cash on Delivery", ar: "كاش عند الاستلام" },
  payCardDelivery: { en: "Card on Delivery", ar: "بطاقة عند الاستلام" },
  uploadScreenshot: { en: "Upload transfer screenshot", ar: "ارفع لقطة التحويل" },
  placeOrder: { en: "Send Order via WhatsApp", ar: "إرسال الطلب عبر واتساب" },
  whatsappConfirmNote: { en: "You'll be redirected to WhatsApp to confirm.", ar: "سيتم تحويلك إلى واتساب للتأكيد." },
};

interface LangCtx {
  lang: Lang;
  setLang: (l: Lang) => void;
  tr: (key: keyof typeof t) => string;
  dir: "ltr" | "rtl";
}

const Ctx = createContext<LangCtx | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    if (typeof window === "undefined") return "en";
    return (localStorage.getItem("mori-lang") as Lang) || "en";
  });

  const dir = lang === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
    localStorage.setItem("mori-lang", lang);
  }, [lang, dir]);

  const tr = (key: keyof typeof t) => t[key]?.[lang] ?? key;

  return (
    <Ctx.Provider value={{ lang, setLang: setLangState, tr, dir }}>
      {children}
    </Ctx.Provider>
  );
}

export function useLang() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useLang must be used inside LanguageProvider");
  return c;
}
