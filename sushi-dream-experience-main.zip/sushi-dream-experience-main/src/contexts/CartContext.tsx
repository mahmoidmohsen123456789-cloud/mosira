// Shopping cart — localStorage-persisted, lightweight
import { createContext, useContext, useEffect, useState, ReactNode, useMemo } from "react";
import type { Dish } from "@/data/menu";

export interface CartLine {
  dish: Dish;
  qty: number;
}

interface CartCtx {
  lines: CartLine[];
  add: (dish: Dish) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  count: number;
  subtotal: number;
  open: boolean;
  setOpen: (o: boolean) => void;
}

const Ctx = createContext<CartCtx | null>(null);
const KEY = "mori-cart-v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(() => {
    if (typeof window === "undefined") return [];
    try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; }
  });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(lines));
  }, [lines]);

  const add = (dish: Dish) => {
    setLines((ls) => {
      const f = ls.find((l) => l.dish.id === dish.id);
      if (f) return ls.map((l) => l.dish.id === dish.id ? { ...l, qty: l.qty + 1 } : l);
      return [...ls, { dish, qty: 1 }];
    });
    setOpen(true);
  };
  const remove = (id: string) => setLines((ls) => ls.filter((l) => l.dish.id !== id));
  const setQty = (id: string, qty: number) => {
    if (qty <= 0) return remove(id);
    setLines((ls) => ls.map((l) => l.dish.id === id ? { ...l, qty } : l));
  };
  const clear = () => setLines([]);

  const { count, subtotal } = useMemo(() => ({
    count: lines.reduce((s, l) => s + l.qty, 0),
    subtotal: lines.reduce((s, l) => s + l.qty * l.dish.price, 0),
  }), [lines]);

  return (
    <Ctx.Provider value={{ lines, add, remove, setQty, clear, count, subtotal, open, setOpen }}>
      {children}
    </Ctx.Provider>
  );
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart must be inside CartProvider");
  return c;
}
