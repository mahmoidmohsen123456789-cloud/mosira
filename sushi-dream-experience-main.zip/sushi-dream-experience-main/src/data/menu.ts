// Mori Sushi curated demo menu — prices in EGP
import maki from "@/assets/dish-maki-combo.jpg";
import combo from "@/assets/dish-sushi-combo.jpg";
import salmonNigiri from "@/assets/dish-salmon-nigiri.jpg";
import tunaNigiri from "@/assets/dish-tuna-nigiri.jpg";
import sashimi from "@/assets/dish-sashimi.jpg";
import dragon from "@/assets/dish-dragon-roll.jpg";
import california from "@/assets/dish-california.jpg";
import spicyTuna from "@/assets/dish-spicy-tuna.jpg";
import teriyaki from "@/assets/dish-teriyaki.jpg";
import tempura from "@/assets/dish-tempura.jpg";
import edamame from "@/assets/dish-edamame.jpg";
import miso from "@/assets/dish-miso.jpg";
import matcha from "@/assets/dish-matcha.jpg";

export type Category = "all" | "maki" | "nigiri" | "sashimi" | "hot" | "sides" | "dessert";

export interface Dish {
  id: string;
  nameAr: string;
  nameEn: string;
  category: Exclude<Category, "all">;
  pieces: number;
  price: number;
  descAr: string;
  descEn: string;
  image: string;
}

export const categories: { id: Category; labelEn: string; labelAr: string }[] = [
  { id: "all", labelEn: "All", labelAr: "الكل" },
  { id: "maki", labelEn: "Maki", labelAr: "ماكي" },
  { id: "nigiri", labelEn: "Nigiri", labelAr: "نيجيري" },
  { id: "sashimi", labelEn: "Sashimi", labelAr: "ساشيمي" },
  { id: "hot", labelEn: "Hot Dishes", labelAr: "أطباق ساخنة" },
  { id: "sides", labelEn: "Sides", labelAr: "جانبية" },
  { id: "dessert", labelEn: "Dessert", labelAr: "حلويات" },
];

export const dishes: Dish[] = [
  { id: "maki-combo", nameEn: "Assorted Maki Combo", nameAr: "ماكي كومبو", category: "maki", pieces: 12, price: 320, descEn: "Fresh maki selection with salmon, tuna and avocado", descAr: "تشكيلة ماكي طازجة بالسلمون والتونة والأفوكادو", image: maki },
  { id: "sushi-combo", nameEn: "Chef's Sushi Combo", nameAr: "سوشي كومبو الشيف", category: "maki", pieces: 16, price: 520, descEn: "Chef's selection of finest nigiri and maki", descAr: "اختيار الشيف من أجود قطع النيجيري والماكي", image: combo },
  { id: "salmon-nigiri", nameEn: "Salmon Nigiri", nameAr: "نيجيري سلمون", category: "nigiri", pieces: 6, price: 240, descEn: "Fresh Norwegian salmon over sushi rice", descAr: "سلمون نرويجي طازج فوق أرز السوشي", image: salmonNigiri },
  { id: "tuna-nigiri", nameEn: "Tuna Nigiri", nameAr: "نيجيري تونة", category: "nigiri", pieces: 6, price: 260, descEn: "Premium red tuna on a pillow of rice", descAr: "تونة حمراء فاخرة على وسادة من الأرز", image: tunaNigiri },
  { id: "sashimi", nameEn: "Salmon Sashimi", nameAr: "ساشيمي سلمون", category: "sashimi", pieces: 8, price: 380, descEn: "Thick salmon slices, pure flavor", descAr: "شرائح سلمون سميكة بدون أرز، نقاء الطعم", image: sashimi },
  { id: "dragon", nameEn: "Dragon Roll", nameAr: "دراجون رول", category: "maki", pieces: 8, price: 340, descEn: "Roll topped with eel, avocado and eel sauce", descAr: "رول مغطى بالأنقليس والأفوكادو وصلصة الأنقليس", image: dragon },
  { id: "california", nameEn: "California Roll", nameAr: "كاليفورنيا رول", category: "maki", pieces: 8, price: 220, descEn: "Crab, avocado and cucumber, topped with roe", descAr: "كراب وأفوكادو وخيار، مغطى ببيض السمك", image: california },
  { id: "spicy-tuna", nameEn: "Spicy Tuna Roll", nameAr: "سبايسي تونة رول", category: "maki", pieces: 8, price: 280, descEn: "Spicy tuna with mayo and green onion", descAr: "تونة حارة بصلصة الميو والبصل الأخضر", image: spicyTuna },
  { id: "teriyaki", nameEn: "Chicken Teriyaki Bowl", nameAr: "دجاج تيرياكي", category: "hot", pieces: 1, price: 220, descEn: "Grilled chicken with teriyaki sauce on Japanese rice", descAr: "دجاج مشوي بصلصة التيرياكي على أرز ياباني", image: teriyaki },
  { id: "tempura", nameEn: "Prawn Tempura", nameAr: "تمبورا جمبري", category: "hot", pieces: 6, price: 290, descEn: "Crispy prawns in Japanese tempura batter", descAr: "جمبري مقرمش بعجينة التمبورا اليابانية", image: tempura },
  { id: "edamame", nameEn: "Edamame", nameAr: "إدامامي", category: "sides", pieces: 1, price: 70, descEn: "Japanese soybeans with sea salt", descAr: "فول الصويا الياباني بملح البحر", image: edamame },
  { id: "miso", nameEn: "Miso Soup", nameAr: "شوربة ميسو", category: "sides", pieces: 1, price: 60, descEn: "Traditional miso soup with tofu and spinach", descAr: "شوربة ميسو تقليدية بالتوفو والسبانخ", image: miso },
  { id: "matcha", nameEn: "Matcha Cheesecake", nameAr: "تشيز كيك ماتشا", category: "dessert", pieces: 1, price: 120, descEn: "Japanese cheesecake with matcha green tea", descAr: "تشيز كيك ياباني بالشاي الأخضر الماتشا", image: matcha },
];
