// Real Google Reviews for Mori Sushi
export interface Review {
  name: string;
  initial: string;
  meta: string;
  time: string;
  rating: number;
  text: string;
  photos?: number;
  likes?: number;
}

export const reviews: Review[] = [
  {
    name: "Alicer",
    initial: "A",
    meta: "مرشد محلي · 61 مراجعة · 19 صورة",
    time: "قبل شهر",
    rating: 3,
    text: "Ramadan buffet: BE CAREFUL — If they offer you sauces or water they're NOT FREE. We ended up paying 500EGP for 6 sauces which is insane especially that the sauces were watered down and tasteless.",
    photos: 19,
  },
  {
    name: "Yousef Elhassan",
    initial: "Y",
    meta: "مراجعة واحدة · 9 صور",
    time: "قبل شهرين",
    rating: 5,
    text: "Food was great loved the place, recommend to go there again 🫶🏻 Ahmed Nasir was a great guy thank you so much ❤️",
    photos: 9,
    likes: 6,
  },
  {
    name: "Dr. Naser",
    initial: "د",
    meta: "مرشد محلي · 308 مراجعات · 403 صور",
    time: "قبل شهر",
    rating: 5,
    text: "المكان جميل وكبير. عائلي وللأفراد. نظيف. لذيذ. يستحق التجربة.",
    photos: 403,
    likes: 5,
  },
];

export const reviewTopics = [
  { label: "بوفيه", count: 23 },
  { label: "تجربة", count: 22 },
  { label: "الضيافة", count: 12 },
  { label: "افطار رمضان", count: 12 },
];

export const ratingBreakdown = [
  { stars: 5, percent: 72 },
  { stars: 4, percent: 16 },
  { stars: 3, percent: 6 },
  { stars: 2, percent: 3 },
  { stars: 1, percent: 3 },
];
