-- Create public bucket for InstaPay payment screenshots
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'instapay-screenshots',
  'instapay-screenshots',
  true,
  5242880,
  array['image/png','image/jpeg','image/jpg','image/webp','image/heic']
)
on conflict (id) do nothing;

-- Public read access
create policy "Public can view instapay screenshots"
on storage.objects for select
using (bucket_id = 'instapay-screenshots');

-- Anonymous upload allowed (checkout has no auth)
create policy "Anyone can upload instapay screenshots"
on storage.objects for insert
with check (bucket_id = 'instapay-screenshots');