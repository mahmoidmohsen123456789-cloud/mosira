

# Mori Sushi — Cinematic 3D Luxury Site (Updated: Film Mode)

Building on the approved plan, adding a **true cinematic "film" feel** plus **client comments / reviews integration** with the real Google data you pasted.

## What's new in this revision

### 🎞️ Film Mode (cinematic upgrades across the whole site)
- **Letterbox bars** — thin black top/bottom bars on the hero (16:9 cinema framing) that slide away on scroll
- **Film grain overlay** — subtle animated noise texture across the entire page (low opacity, gold-tinted)
- **Chromatic aberration + vignette** post-processing on the 3D scene (R3F EffectComposer) for a warm anamorphic-lens look
- **Lens flares** sweeping across the gold accent lights as the camera orbits
- **Scene "shot" cuts** — every ~6s the camera smoothly cuts to a new framing (wide → close-up dolly → top-down → orbit), like a film edit, instead of one continuous orbit
- **Cinematic color grade** — teal/orange LUT-style tone mapping (warm gold highlights, cool deep shadows)
- **Slow depth-of-field** — front sushi plate sharp, others softly blurred; focus rack shifts between cuts
- **Opening title card** — after loader: "MORI SUSHI" fades in with a subtitle *"A Film by the Chefs of New Cairo · Est. Open Air Mall"* then dissolves into the hero
- **Section transitions** — quick black "fade to black" wipe + soft film-reel click sound (toggleable, off by default)

### 💬 Client Comments — real Google reviews integrated
Replacing the placeholder reviews section with the actual data you provided:

- **Header stats card**
  - Big "4.6 ★" with 5-star breakdown bars
  - "1,832 مراجعة على Google · $$$"
  - Topic chips: بوفيه (23) · تجربة (22) · الضيافة (12) · افطار رمضان (12) · +6
- **Three featured review cards** (gold-bordered, film-still styled with subtle grain):
  1. **Alicer** — Local Guide · 61 reviews · 19 photos · 1 month ago — full Ramadan buffet sauce warning text
  2. **Yousef Elhassan** — 1 review · 9 photos · 2 months ago — "Food was great loved the place... Ahamed Nasir was a great guy 🫶🏻"
  3. **Dr. Naser** — Local Guide · 308 reviews · 403 photos · 1 month ago — "المكان جميل وكبير. عائلي وللأفراد. نظيف. لذيذ. يستحق التجربة"
- Each card: avatar initial in gold circle, name, reviewer meta, time, star row, full review text, like/share row
- "كتابة مراجعة" gold CTA + "عرض جميع المراجعات (1,829+)" link to Google Maps listing
- Cards reveal with staggered GSAP fade + slight scale, like film stills laid on a table

### 📍 Location card enriched with real data
- Address: *Food Hall — Open Air Mall, ثاني القاهرة الجديدة*
- Plus code: 4J4G+MC
- Status pill: **مغلق · يفتح ١٢ م** (live computed from current time)
- Service badges: الطلب على الإنترنت · الجلوس داخل المكان · طعام سفري · التسليم بدون تلامس
- Phone 012 0888 8492 · website mori-sushi.com · menu flexmenus.darwinz.ai
- "أوقات الزحمة" mini bar chart (Wednesdays peak visualization)

## Everything from the approved plan still applies
3D rotating sushi carousel (10 plates) · 50 gold particles · WebGL fallback · custom halo cursor · cart + WhatsApp ordering to wa.me/201208888492 · piece-count badges on every dish · ultra-3D card tilt · 19 AI-generated 4K sushi images · GSAP scroll reveals · RTL Arabic · dark `#0A0A0A` + gold `#D4A853` · About / Gallery / Reviews / Location sections.

## Tech additions
- `@react-three/postprocessing` → vignette, chromatic aberration, bloom, depth of field
- Camera "shot list" controller (custom hook cycling through framing presets with GSAP tweens)
- SVG film-grain + scanline overlay component (CSS animated)
- Reviews stored as a typed array in `src/data/reviews.ts` for easy editing

